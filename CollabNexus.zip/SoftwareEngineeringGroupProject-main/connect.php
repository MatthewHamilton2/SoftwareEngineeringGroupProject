<?php
    $conn = mysqli_connect('database-2.cnqeamc2mgky.eu-north-1.rds.amazonaws.com', 'admin', 'Pass12345', 'studentwebsite', '3306');
?>